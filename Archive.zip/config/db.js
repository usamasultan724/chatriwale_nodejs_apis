const mysql = require('mysql2');
// require('dotenv').config();

// const db = mysql.createConnection({
//   host: process.env.MY_HOST,
//   user: process.env.MY_USER,
//   password: process.env.MY_PASS,
//   database: process.env.MY_DB
// });

// const db = mysql.createConnection({
//   host: 'localhost',
//   user: 'qpdtkzda_qpdtkzda',
//   password: '7[BO4a4p4jYr[U',
//   database: 'qpdtkzda_chatriwale_db'
// });

const db = mysql.createConnection({
    host: 'localhost',
    user: 'qpdtkzda_qpdtkzda',
    password: '7[BO4a4p4jYr[U' ,
    database: 'chatriwale_db'
  });

db.connect(err => {
    if (err) {
      console.error('Error connecting to the database:', err);
      return;
    }
    console.log('Connected to MySQL database');
  });
  

module.exports = db;
